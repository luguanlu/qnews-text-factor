from pathlib import Path

from qnews.backtest import run_backtest
from qnews.demo import make_demo_data
from qnews.pipeline import prepare_panel, run_comparison
from qnews.sentiment import aggregate_daily_sentiment


def _settings(output_dir: Path) -> dict:
    return {
        "train_days": 120, "fit_days": 90, "calibration_days": 30, "test_days": 20,
        "top_k": 10, "probability_threshold": 0.55, "max_weight": 0.10,
        "rebalance_threshold": 0.02, "transaction_cost": 0.0015, "annualization_days": 242,
        "lasso_c": 0.03, "pca_components": 8, "svm_c_grid": [0.25, 1.0],
        "svm_gamma_grid": ["scale"], "random_state": 7, "output_dir": str(output_dir),
    }


def test_sentiment_is_moved_to_next_trading_day():
    market, news = make_demo_data(n_tickers=4, n_dates=8)
    daily = aggregate_daily_sentiment(news.iloc[:1], market_dates=market["date"].unique())
    assert daily["date"].iloc[0] > news["published_at"].iloc[0].normalize()


def test_demo_pipeline_runs_end_to_end(tmp_path: Path):
    market, news = make_demo_data()
    panel, features = prepare_panel(market, news)
    assert len(features) == 12
    results = run_comparison(market, news, _settings(tmp_path))
    assert set(results["metrics"]["strategy"]) == {"pca_only", "text_pca"}
    assert not results["predictions"].empty
    assert (tmp_path / "pca_only_daily_backtest.csv").exists()
