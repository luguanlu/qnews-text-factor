#!/usr/bin/env python3
"""Apply a user-selected Chinese finance sentiment checkpoint to matched news."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from qnews.sentiment import score_with_transformers


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Matched news CSV")
    parser.add_argument("--output", required=True, help="Scored-news CSV")
    parser.add_argument("--model-id", required=True, help="Hugging Face model identifier or local checkpoint")
    parser.add_argument(
        "--label-map", required=True,
        help='JSON mapping of semantic names to checkpoint labels, e.g. {"positive":"LABEL_2","neutral":"LABEL_1","negative":"LABEL_0"}',
    )
    parser.add_argument("--batch-size", type=int, default=16)
    args = parser.parse_args()
    labels = json.loads(args.label_map)
    scored = score_with_transformers(pd.read_csv(args.input), args.model_id, labels, args.batch_size)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    scored.to_csv(args.output, index=False)
    print(f"Wrote {len(scored):,} scored articles to {args.output}")


if __name__ == "__main__":
    main()
