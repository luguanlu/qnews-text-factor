#!/usr/bin/env python3
"""Run PCA-only and Text-PCA rolling SVM strategies on local CSV inputs."""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from qnews.pipeline import load_settings, run_comparison, write_results


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--market", required=True, help="CSV: date,ticker,open,close plus numeric traditional factors")
    parser.add_argument("--news", help="Optional scored CSV: published_at,ticker,title,content,sentiment_score")
    parser.add_argument("--config", default="config/default.json")
    parser.add_argument("--output-dir", default="outputs/demo")
    args = parser.parse_args()
    settings = load_settings(args.config)
    settings["output_dir"] = args.output_dir
    Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    market = pd.read_csv(args.market)
    news = pd.read_csv(args.news) if args.news else None
    results = run_comparison(market, news, settings)
    write_results(results, args.output_dir)
    print(results["metrics"].to_string(index=False, float_format=lambda value: f"{value:.4f}"))
    print(f"Results written to {args.output_dir}")


if __name__ == "__main__":
    main()
