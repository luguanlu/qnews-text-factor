#!/usr/bin/env python3
"""Create an offline input pair that exercises the complete pipeline."""
from pathlib import Path
import argparse

from qnews.demo import make_demo_data


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default="data/demo")
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    market, news = make_demo_data()
    market.to_csv(output / "market.csv", index=False)
    news.to_csv(output / "news_scored.csv", index=False)
    print(f"Wrote {len(market):,} market rows and {len(news):,} scored news rows to {output}")


if __name__ == "__main__":
    main()
