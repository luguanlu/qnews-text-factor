#!/usr/bin/env python3
"""Download a CSI 500 market panel and Eastmoney news using a Tushare token.

This command deliberately writes untracked raw data.  Some Tushare endpoints
need account-specific permissions; the script reports endpoint failures instead
of silently substituting a different data source.
"""
from __future__ import annotations

import argparse
import os
import time
from pathlib import Path

import pandas as pd


def date_code(value: str) -> str:
    return pd.Timestamp(value).strftime("%Y%m%d")


def require_token() -> str:
    token = os.environ.get("TUSHARE_TOKEN")
    if not token:
        raise SystemExit("Set TUSHARE_TOKEN first; see .env.example.")
    return token


def universe_from_index(pro, start: str, end: str) -> list[str]:
    weights = pro.index_weight(index_code="000905.SH", start_date=start, end_date=end)
    if weights.empty:
        raise RuntimeError("Tushare returned no CSI 500 index weights for this period")
    return sorted(weights["con_code"].dropna().unique().tolist())


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--start", required=True, help="YYYY-MM-DD")
    parser.add_argument("--end", required=True, help="YYYY-MM-DD")
    parser.add_argument("--output-dir", default="data/raw")
    parser.add_argument("--sleep-seconds", type=float, default=0.12)
    parser.add_argument("--skip-news", action="store_true")
    args = parser.parse_args()
    try:
        import tushare as ts
    except ImportError as exc:
        raise SystemExit("Install live-data dependencies: pip install -e '.[live-data]'") from exc
    start, end = date_code(args.start), date_code(args.end)
    pro = ts.pro_api(require_token())
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    tickers = universe_from_index(pro, start, end)
    market_chunks: list[pd.DataFrame] = []
    failures: list[str] = []
    for index, ticker in enumerate(tickers, 1):
        try:
            daily = pro.daily(ts_code=ticker, start_date=start, end_date=end)
            basic = pro.daily_basic(ts_code=ticker, start_date=start, end_date=end)
            factors = pro.stk_factor_pro(ts_code=ticker, start_date=start, end_date=end)
            merged = daily.merge(basic, on=["ts_code", "trade_date"], how="left", suffixes=("", "_basic"))
            merged = merged.merge(factors, on=["ts_code", "trade_date"], how="left", suffixes=("", "_factor"))
            market_chunks.append(merged)
        except Exception as exc:  # endpoint permissions are data-provider-specific
            failures.append(f"{ticker}: {type(exc).__name__}: {exc}")
        if index % 25 == 0:
            print(f"Processed {index}/{len(tickers)} tickers")
        time.sleep(args.sleep_seconds)
    if not market_chunks:
        raise RuntimeError("No market data downloaded. Inspect Tushare permissions and the failure log.")
    market = pd.concat(market_chunks, ignore_index=True).rename(columns={"ts_code": "ticker", "trade_date": "date"})
    market["date"] = pd.to_datetime(market["date"])
    market.to_csv(output / "market.csv", index=False)
    (output / "download_failures.txt").write_text("\n".join(failures), encoding="utf-8")
    print(f"Wrote {len(market):,} market rows; {len(failures)} ticker downloads failed.")
    if args.skip_news:
        return
    news = pro.news(src="eastmoney", start_date=start, end_date=end)
    if news.empty:
        print("Tushare returned no Eastmoney news; market export is still available.")
        return
    basics = pro.stock_basic(exchange="", list_status="L", fields="ts_code,name")
    names = basics.set_index("ts_code")["name"].dropna().to_dict()
    text_column = "content" if "content" in news else "title"
    matches: list[str | None] = []
    for _, article in news.iterrows():
        text = str(article.get("title", "")) + str(article.get(text_column, ""))
        candidates = [code for code, name in names.items() if name and str(name) in text]
        matches.append(candidates[0] if len(candidates) == 1 else None)
    news["ticker"] = matches
    news = news.dropna(subset=["ticker"])
    news = news.rename(columns={"datetime": "published_at"})
    for column in ("title", "content"):
        if column not in news:
            news[column] = ""
    news[["published_at", "ticker", "title", "content"]].to_csv(output / "matched_news.csv", index=False)
    print(f"Wrote {len(news):,} uniquely matched news articles.")


if __name__ == "__main__":
    main()
