"""Input contracts and validation helpers for the panel data pipeline."""
from __future__ import annotations

import pandas as pd

PANEL_REQUIRED = {"date", "ticker", "open", "close"}
NEWS_REQUIRED = {"published_at", "ticker", "title", "content"}


def validate_panel(frame: pd.DataFrame) -> pd.DataFrame:
    missing = PANEL_REQUIRED - set(frame.columns)
    if missing:
        raise ValueError(f"market panel is missing required columns: {sorted(missing)}")
    result = frame.copy()
    result["date"] = pd.to_datetime(result["date"], errors="raise").dt.normalize()
    result["ticker"] = result["ticker"].astype(str)
    result = result.sort_values(["date", "ticker"]).drop_duplicates(["date", "ticker"])
    if result[["open", "close"]].isna().any().any():
        raise ValueError("open and close must be non-null before labeling returns")
    return result


def validate_news(frame: pd.DataFrame) -> pd.DataFrame:
    missing = NEWS_REQUIRED - set(frame.columns)
    if missing:
        raise ValueError(f"news table is missing required columns: {sorted(missing)}")
    result = frame.copy()
    result["published_at"] = pd.to_datetime(result["published_at"], errors="raise")
    result["ticker"] = result["ticker"].astype(str)
    result["title"] = result["title"].fillna("").astype(str)
    result["content"] = result["content"].fillna("").astype(str)
    return result
