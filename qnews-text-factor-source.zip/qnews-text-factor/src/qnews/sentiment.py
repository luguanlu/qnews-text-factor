"""News matching, inference, and daily sentiment aggregation."""
from __future__ import annotations

from collections.abc import Mapping
import pandas as pd

from .schema import validate_news


def score_with_transformers(
    news: pd.DataFrame,
    model_id: str,
    label_map: Mapping[str, str],
    batch_size: int = 16,
) -> pd.DataFrame:
    """Score a Chinese finance model and return positive-minus-negative sentiment.

    ``label_map`` maps semantic names to the checkpoint labels, for example
    ``{"positive": "LABEL_2", "negative": "LABEL_0"}``. It is explicit
    because financial checkpoints do not share one universal label order.
    """
    try:
        from transformers import pipeline
    except ImportError as exc:  # pragma: no cover - depends on optional extra
        raise ImportError("Install the NLP extra: pip install -e '.[nlp]'") from exc
    result = validate_news(news)
    texts = (result["title"] + "。" + result["content"]).tolist()
    classifier = pipeline("text-classification", model=model_id, top_k=None)
    predictions = classifier(texts, batch_size=batch_size, truncation=True, max_length=512)
    positive_key = next((key for key in label_map if key.lower() in {"positive", "pos", "利好"}), None)
    negative_key = next((key for key in label_map if key.lower() in {"negative", "neg", "利空"}), None)
    if positive_key is None or negative_key is None:
        raise ValueError("label_map must identify positive and negative labels")
    def score_article(items: list[dict]) -> float:
        probabilities = {str(item["label"]): float(item["score"]) for item in items}
        try:
            return probabilities[label_map[positive_key]] - probabilities[label_map[negative_key]]
        except KeyError as exc:
            raise ValueError(f"checkpoint response lacks mapped label {exc.args[0]!r}") from exc

    result["sentiment_score"] = [score_article(item) for item in predictions]
    return result


def aggregate_daily_sentiment(news: pd.DataFrame, market_dates: pd.DatetimeIndex | None = None) -> pd.DataFrame:
    """Map each article to its next available trading date and aggregate by stock.

    Articles are intentionally shifted to the next session, so a same-day close
    cannot be predicted from news that was published after market close.
    """
    result = validate_news(news)
    if "sentiment_score" not in result:
        raise ValueError("news must include sentiment_score before aggregation")
    result["signal_date"] = result["published_at"].dt.normalize()
    if market_dates is not None:
        calendar = pd.DatetimeIndex(sorted(pd.to_datetime(market_dates).normalize().unique()))
        if calendar.empty:
            raise ValueError("market_dates is empty")
        indexer = calendar.searchsorted(result["signal_date"].to_numpy(), side="right")
        result["date"] = [calendar[i] if i < len(calendar) else pd.NaT for i in indexer]
        result = result.dropna(subset=["date"])
    else:
        result["date"] = result["signal_date"] + pd.offsets.BDay(1)
    daily = result.groupby(["date", "ticker"], as_index=False).agg(
        sentiment_score=("sentiment_score", "mean"),
        news_count=("sentiment_score", "size"),
    )
    return daily
