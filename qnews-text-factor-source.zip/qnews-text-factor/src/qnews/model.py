"""Rolling, time-ordered SVM prediction with an explicit calibration period."""
from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Any

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from .features import LassoPCA


@dataclass
class RollingResult:
    predictions: pd.DataFrame
    diagnostics: pd.DataFrame


class PlattCalibrator:
    """Small wrapper that also handles an all-one-class calibration sample."""

    def fit(self, scores: np.ndarray, y: np.ndarray) -> "PlattCalibrator":
        self.constant_ = None
        if len(np.unique(y)) < 2:
            self.constant_ = float(np.mean(y))
        else:
            self.model_ = LogisticRegression(C=1e6, solver="lbfgs")
            self.model_.fit(np.asarray(scores).reshape(-1, 1), y)
        return self

    def predict(self, scores: np.ndarray) -> np.ndarray:
        if self.constant_ is not None:
            return np.full(len(scores), self.constant_)
        return self.model_.predict_proba(np.asarray(scores).reshape(-1, 1))[:, 1]


def _fit_svm(x: pd.DataFrame, y: pd.Series, c: float, gamma: str | float) -> tuple[StandardScaler, SVC]:
    scaler = StandardScaler()
    transformed = scaler.fit_transform(x)
    model = SVC(C=c, gamma=gamma, kernel="rbf", class_weight="balanced", random_state=7)
    model.fit(transformed, y)
    return scaler, model


def _time_cv_params(x: pd.DataFrame, y: pd.Series, dates: pd.Series, c_grid: list[float], gamma_grid: list[str | float]) -> tuple[float, str | float, float]:
    """Expanding date-based validation. No row from a later date enters training."""
    unique_dates = np.array(sorted(pd.to_datetime(dates).unique()))
    if len(unique_dates) < 12 or len(np.unique(y)) < 2:
        return c_grid[0], gamma_grid[0], np.nan
    cut_points = [len(unique_dates) // 2, (2 * len(unique_dates)) // 3]
    candidates: list[tuple[float, float, str | float]] = []
    for c, gamma in product(c_grid, gamma_grid):
        scores: list[float] = []
        for cut in cut_points:
            train_dates = unique_dates[:cut]
            validation_dates = unique_dates[cut:min(cut + max(5, len(unique_dates) // 6), len(unique_dates))]
            train_mask = dates.isin(train_dates)
            valid_mask = dates.isin(validation_dates)
            if y[train_mask].nunique() < 2 or y[valid_mask].nunique() < 2:
                continue
            scaler, model = _fit_svm(x.loc[train_mask], y.loc[train_mask], c, gamma)
            pred = model.decision_function(scaler.transform(x.loc[valid_mask]))
            scores.append(roc_auc_score(y.loc[valid_mask], pred))
        candidates.append((float(np.mean(scores)) if scores else -np.inf, c, gamma))
    score, c, gamma = max(candidates, key=lambda item: item[0])
    return c, gamma, score if np.isfinite(score) else np.nan


def run_rolling_svm(
    panel: pd.DataFrame,
    traditional_features: list[str],
    include_sentiment: bool,
    settings: dict[str, Any],
) -> RollingResult:
    """Fit the two-stage model and make only genuinely out-of-sample predictions.

    The panel must contain a one-day-ahead ``target`` and ``next_return``. PCA
    and scaling are refit per rolling window, using the initial fit segment
    only; the final 30 dates are strictly reserved for Platt calibration.
    """
    required = {"date", "ticker", "target", "next_return", *traditional_features}
    if include_sentiment:
        required.add("sentiment_score")
    missing = required - set(panel.columns)
    if missing:
        raise ValueError(f"panel missing model columns: {sorted(missing)}")
    frame = panel.dropna(subset=["target", "next_return"]).sort_values(["date", "ticker"]).reset_index(drop=True)
    dates = np.array(sorted(frame["date"].unique()))
    train_days = settings["train_days"]
    fit_days = settings["fit_days"]
    calibration_days = settings["calibration_days"]
    test_days = settings["test_days"]
    if fit_days + calibration_days != train_days:
        raise ValueError("fit_days + calibration_days must equal train_days")
    predictions, diagnostics = [], []
    for start in range(0, len(dates) - train_days - test_days + 1, test_days):
        fit_dates = dates[start:start + fit_days]
        calibration_dates = dates[start + fit_days:start + train_days]
        test_dates = dates[start + train_days:start + train_days + test_days]
        fit_part = frame[frame.date.isin(fit_dates)].copy()
        calibration_part = frame[frame.date.isin(calibration_dates)].copy()
        test_part = frame[frame.date.isin(test_dates)].copy()
        y_fit = fit_part["target"].astype(int)
        if y_fit.nunique() < 2:
            continue
        reducer = LassoPCA(c=settings["lasso_c"], n_components=settings["pca_components"], random_state=settings["random_state"])
        reducer.fit(fit_part[traditional_features], y_fit)
        x_fit = reducer.transform(fit_part[traditional_features])
        x_cal = reducer.transform(calibration_part[traditional_features])
        x_test = reducer.transform(test_part[traditional_features])
        if include_sentiment:
            for matrix, part in ((x_fit, fit_part), (x_cal, calibration_part), (x_test, test_part)):
                matrix["sentiment_score"] = part["sentiment_score"].fillna(0.0).to_numpy()
        c, gamma, validation_auc = _time_cv_params(
            x_fit, y_fit, fit_part["date"], settings["svm_c_grid"], settings["svm_gamma_grid"],
        )
        scaler, svm = _fit_svm(x_fit, y_fit, c, gamma)
        calibration_scores = svm.decision_function(scaler.transform(x_cal))
        calibrator = PlattCalibrator().fit(calibration_scores, calibration_part["target"].astype(int).to_numpy())
        probabilities = calibrator.predict(svm.decision_function(scaler.transform(x_test)))
        predictions.append(test_part[["date", "ticker", "next_return"]].assign(up_probability=probabilities))
        diagnostics.append({
            "prediction_start": pd.Timestamp(test_dates[0]), "prediction_end": pd.Timestamp(test_dates[-1]),
            "include_sentiment": include_sentiment, "selected_features": ";".join(reducer.selected_columns_),
            "pca_components": len(reducer.output_columns_), "pca_variance_explained": float(reducer.explained_variance_ratio_.sum()),
            "cv_auc": validation_auc, "svm_c": c, "svm_gamma": gamma,
        })
    if not predictions:
        raise ValueError("not enough valid dates to form one rolling train/calibration/test window")
    return RollingResult(pd.concat(predictions, ignore_index=True), pd.DataFrame(diagnostics))
