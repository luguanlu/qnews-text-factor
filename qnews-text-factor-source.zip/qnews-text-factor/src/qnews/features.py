"""Leakage-aware LASSO selection and PCA feature construction."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectFromModel
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


class LassoPCA:
    """Select relevant traditional factors with L1-logit, then reduce via PCA."""

    def __init__(self, c: float = 0.03, n_components: int = 8, random_state: int = 7):
        self.c = c
        self.n_components = n_components
        self.random_state = random_state

    def fit(self, x: pd.DataFrame, y: pd.Series) -> "LassoPCA":
        if x.empty:
            raise ValueError("traditional-factor matrix is empty")
        self.columns_ = list(x.columns)
        selector_model = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
            ("logit", LogisticRegression(penalty="l1", solver="liblinear", C=self.c, random_state=self.random_state)),
        ])
        selector_model.fit(x, y)
        coefficients = selector_model.named_steps["logit"].coef_.ravel()
        chosen = np.flatnonzero(np.abs(coefficients) > 1e-10)
        # A very strong penalty can select no feature in small rolling windows.
        if len(chosen) == 0:
            chosen = np.argsort(np.abs(coefficients))[-min(1, len(coefficients)):]
        self.selected_columns_ = [self.columns_[i] for i in chosen]
        max_components = min(self.n_components, len(self.selected_columns_), len(x))
        self.reducer_ = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
            ("pca", PCA(n_components=max_components, random_state=self.random_state)),
        ])
        self.reducer_.fit(x[self.selected_columns_])
        self.output_columns_ = [f"pc_{i + 1}" for i in range(max_components)]
        return self

    def transform(self, x: pd.DataFrame) -> pd.DataFrame:
        missing = set(self.selected_columns_) - set(x.columns)
        if missing:
            raise ValueError(f"feature columns missing at transform time: {sorted(missing)}")
        values = self.reducer_.transform(x[self.selected_columns_])
        return pd.DataFrame(values, index=x.index, columns=self.output_columns_)

    @property
    def explained_variance_ratio_(self) -> np.ndarray:
        return self.reducer_.named_steps["pca"].explained_variance_ratio_
