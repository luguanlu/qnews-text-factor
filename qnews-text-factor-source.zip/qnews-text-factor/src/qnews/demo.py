"""Generate a deterministic synthetic data set for an offline smoke test."""
from __future__ import annotations

import numpy as np
import pandas as pd


def make_demo_data(n_tickers: int = 32, n_dates: int = 190, seed: int = 7) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2023-01-02", periods=n_dates)
    tickers = [f"{code:06d}.SZ" for code in range(1, n_tickers + 1)]
    records, articles = [], []
    latent = rng.normal(0, 1, size=(n_dates, n_tickers))
    feature_state = rng.normal(0, 1, size=(n_tickers, 12))
    closes = np.full(n_tickers, 10.0)
    for day_index, date in enumerate(dates):
        signal = latent[day_index]
        factors = feature_state + rng.normal(0, 0.25, size=feature_state.shape)
        # The next-session return has a weak traditional-factor signal and an
        # additional sentiment signal. This is for integration testing only.
        next_signal = (0.004 * factors[:, 0] - 0.003 * factors[:, 1] + 0.006 * signal
                       + rng.normal(0, 0.012, n_tickers))
        opens = closes * (1 + rng.normal(0, 0.005, n_tickers))
        closes = opens * (1 + next_signal)
        for ticker_index, ticker in enumerate(tickers):
            row = {"date": date, "ticker": ticker, "open": opens[ticker_index], "close": closes[ticker_index],
                   "volume": float(rng.lognormal(14, 0.5))}
            row.update({f"factor_{factor_index + 1:02d}": factors[ticker_index, factor_index] for factor_index in range(12)})
            records.append(row)
            if rng.random() < 0.55:
                articles.append({
                    "published_at": date + pd.Timedelta(hours=18), "ticker": ticker,
                    "title": "模拟财经快讯", "content": "Synthetic finance news for reproducibility testing.",
                    # News published after today's close is allowed to affect
                    # tomorrow's close, never today's already observed close.
                    "sentiment_score": float(latent[min(day_index + 2, n_dates - 1), ticker_index]),
                })
        feature_state = 0.94 * feature_state + rng.normal(0, 0.12, size=feature_state.shape)
    return pd.DataFrame(records), pd.DataFrame(articles)
