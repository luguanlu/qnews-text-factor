"""Tools for testing whether finance-news sentiment adds predictive value."""

__version__ = "0.1.0"
