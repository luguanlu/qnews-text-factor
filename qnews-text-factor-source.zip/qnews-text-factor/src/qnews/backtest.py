"""Long-only, probability-ranked portfolio simulation with transaction costs."""
from __future__ import annotations

import numpy as np
import pandas as pd


def _cap_weights(raw: pd.Series, cap: float) -> pd.Series:
    weights = raw.copy().clip(lower=0)
    if weights.sum() == 0:
        return weights
    weights /= weights.sum()
    for _ in range(len(weights) + 1):
        over = weights > cap + 1e-12
        if not over.any():
            break
        excess = (weights[over] - cap).sum()
        weights.loc[over] = cap
        recipients = ~over
        if not recipients.any() or excess <= 1e-12:
            break
        base = weights.loc[recipients]
        weights.loc[recipients] += excess * base / base.sum() if base.sum() else excess / recipients.sum()
    return weights


def target_weights(
    day: pd.DataFrame, threshold: float, top_k: int, max_weight: float,
) -> pd.Series:
    eligible = day.loc[day["up_probability"] >= threshold].nlargest(top_k, "up_probability").copy()
    if eligible.empty:
        return pd.Series(dtype=float)
    confidence = (eligible["up_probability"] - 0.5).clip(lower=0)
    return _cap_weights(pd.Series(confidence.to_numpy(), index=eligible["ticker"]), max_weight)


def run_backtest(
    predictions: pd.DataFrame,
    threshold: float = 0.55,
    top_k: int = 10,
    max_weight: float = 0.10,
    rebalance_threshold: float = 0.02,
    transaction_cost: float = 0.0015,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Backtest decisions at t against already aligned next-session returns."""
    required = {"date", "ticker", "up_probability", "next_return"}
    missing = required - set(predictions.columns)
    if missing:
        raise ValueError(f"predictions missing columns: {sorted(missing)}")
    records, holdings = [], pd.Series(dtype=float)
    for date, day in predictions.sort_values(["date", "ticker"]).groupby("date", sort=True):
        desired = target_weights(day, threshold, top_k, max_weight)
        universe = holdings.index.union(desired.index)
        current = holdings.reindex(universe, fill_value=0.0)
        target = desired.reindex(universe, fill_value=0.0)
        changed = (current - target).abs() > rebalance_threshold
        executed = current.where(~changed, target)
        executed = executed[executed > 1e-12]
        realized = day.set_index("ticker")["next_return"].reindex(executed.index).fillna(0.0)
        turnover = float((executed.reindex(universe, fill_value=0.0) - current).abs().sum())
        gross_return = float((executed * realized).sum())
        net_return = gross_return - turnover * transaction_cost
        records.append({"date": date, "gross_return": gross_return, "net_return": net_return,
                        "turnover": turnover, "n_holdings": len(executed), "cash_weight": 1 - executed.sum()})
        holdings = executed
    daily = pd.DataFrame(records)
    if not daily.empty:
        daily["nav"] = (1 + daily["net_return"]).cumprod()
    return daily, holdings.rename("weight").rename_axis("ticker").reset_index()


def performance_metrics(daily: pd.DataFrame, annualization_days: int = 242) -> dict[str, float]:
    if daily.empty:
        return {"annualized_return": np.nan, "sharpe": np.nan, "max_drawdown": np.nan,
                "average_turnover": np.nan, "average_holdings": np.nan}
    returns = daily["net_return"]
    periods = len(returns)
    annualized = daily["nav"].iloc[-1] ** (annualization_days / periods) - 1
    std = returns.std(ddof=1)
    sharpe = np.sqrt(annualization_days) * returns.mean() / std if std > 0 else np.nan
    drawdown = daily["nav"] / daily["nav"].cummax() - 1
    return {
        "annualized_return": float(annualized),
        "sharpe": float(sharpe),
        "max_drawdown": float(-drawdown.min()),
        "average_turnover": float(daily["turnover"].mean()),
        "average_holdings": float(daily["n_holdings"].mean()),
    }
