"""End-to-end data preparation and model comparison."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd

from .backtest import performance_metrics, run_backtest
from .model import run_rolling_svm
from .schema import validate_panel
from .sentiment import aggregate_daily_sentiment


def load_settings(path: str | Path) -> dict[str, Any]:
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def prepare_panel(market: pd.DataFrame, news: pd.DataFrame | None = None) -> tuple[pd.DataFrame, list[str]]:
    panel = validate_panel(market)
    # ``transform`` preserves ticker boundaries, so a return never crosses stocks.
    panel["next_return"] = panel.groupby("ticker")["close"].transform(lambda close: close.shift(-1) / close - 1)
    panel["target"] = (panel["next_return"] > 0).astype("Int64")
    protected = {"date", "ticker", "open", "close", "next_return", "target", "volume", "sentiment_score", "news_count"}
    traditional_features = [
        column for column in panel.select_dtypes(include="number").columns if column not in protected
    ]
    if not traditional_features:
        raise ValueError("market data needs at least one numeric traditional factor besides OHLC/volume")
    if news is not None:
        daily_sentiment = aggregate_daily_sentiment(news, pd.DatetimeIndex(panel["date"].unique()))
        panel = panel.merge(daily_sentiment, on=["date", "ticker"], how="left")
        panel["sentiment_score"] = panel["sentiment_score"].fillna(0.0)
        panel["news_count"] = panel["news_count"].fillna(0).astype(int)
    elif "sentiment_score" not in panel:
        panel["sentiment_score"] = 0.0
    return panel, traditional_features


def run_comparison(market: pd.DataFrame, news: pd.DataFrame | None, settings: dict[str, Any]) -> dict[str, pd.DataFrame]:
    panel, traditional_features = prepare_panel(market, news)
    all_predictions, all_diagnostics, metrics = [], [], []
    for name, include_sentiment in (("pca_only", False), ("text_pca", True)):
        rolling = run_rolling_svm(panel, traditional_features, include_sentiment, settings)
        daily, _ = run_backtest(
            rolling.predictions,
            threshold=settings["probability_threshold"], top_k=settings["top_k"], max_weight=settings["max_weight"],
            rebalance_threshold=settings["rebalance_threshold"], transaction_cost=settings["transaction_cost"],
        )
        all_predictions.append(rolling.predictions.assign(strategy=name))
        all_diagnostics.append(rolling.diagnostics.assign(strategy=name))
        metrics.append({"strategy": name, **performance_metrics(daily, settings["annualization_days"])})
        daily.to_csv(Path(settings["output_dir"]) / f"{name}_daily_backtest.csv", index=False)
    return {
        "predictions": pd.concat(all_predictions, ignore_index=True),
        "diagnostics": pd.concat(all_diagnostics, ignore_index=True),
        "metrics": pd.DataFrame(metrics),
        "prepared_panel": panel,
    }


def write_results(results: dict[str, pd.DataFrame], output_dir: str | Path) -> None:
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    for name, frame in results.items():
        frame.to_csv(destination / f"{name}.csv", index=False)
